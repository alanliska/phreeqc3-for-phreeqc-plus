// Interpolator.cpp : Defines the entry point for the console application.
//
#include "TsvData.h"

int main(int argc, char* argv[])
{
	//TsvData *tsvdata = new TsvData();
	
	return 0;
}

